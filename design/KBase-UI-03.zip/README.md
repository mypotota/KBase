# KBase · UI 03

React + TypeScript + 官方 shadcn/ui 交互原型。本版重新设计为：

**初始化知识库 → 项目列表 → 项目工作台。**

以 Apple 桌面软件的克制排版、窗口比例与留白为参考，只提供白色和深色外观。没有彩色主题或大面积强调色；只有项目文件夹图标使用少量颜色。

## 查看设计

打开 `prototype/index.html`，或解压 `design/KBase-shadcn-UI-preview.zip` 中的同名文件。JavaScript 与 CSS 已内联，不依赖 CDN。当前环境浏览器禁止 `file://` 导航，因此交付文件通过静态 HTTP 服务验证；直接打开文件方式未在本环境验证。

底部小型评审入口可切换初始化、示例项目、示例工作台和移动预览。该入口仅属于评审稿，不作为正式产品导航。

1. 初始化页：选择已有文件夹，或新建根知识库；支持回到最近使用的知识库。
2. 项目页：新建项目、查看空状态、按名称筛选项目。
3. 工作台：点击项目进入，管理文档、编辑、保存与导出。
4. 同步、日志、外观与大纲按需通过官方 Sheet / Dialog 打开。

本版设计说明：`design/UI-03.md`。截图：`design/previews/`。

## 真实 shadcn/ui 组件

`web/src/components/ui/` 保留官方组件源码，来自 https://github.com/shadcn-ui/ui 的固定提交：

`96da9cc7f1aa10580a3741664e2a77c721206c00`

来源说明见 `web/SHADCN-SOURCE.md`，MIT 许可证见 `web/SHADCN-LICENSE`。官方注册站在此环境不可访问，因此源码通过官方 GitHub 仓库取得，只修改导入别名。

当前 App 直接使用 Button、Input、Textarea、Dialog、DropdownMenu、Sheet、ScrollArea、Separator、Switch、Tabs、Command、Resizable、Tooltip 和 Sonner。未创建自定义按钮、弹窗、菜单或面板控件；CSS 负责灰阶主题、页面布局与尺寸。其余已下载的官方组件保留供后续实现使用。

## 开发、构建与静态服务

```sh
cd /workspace/KBase/web
npm ci
npm run dev -- --port 4174
```

```sh
cd /workspace/KBase/web
npm run build
```

构建产物为 `web/dist/index.html`。更新交付稿时复制到 `prototype/index.html`，并保留 MIT 许可证；当前交付 HTML 已附许可证注释。

```sh
cd /workspace/KBase
python3 -m http.server 4173 --bind 0.0.0.0 --directory prototype
```

Docker 配置保留供日后部署，尚未验证容器构建：

```sh
docker compose up -d --build
```

映射端口为 8080，公开提供时应置于 HTTPS 反向代理后。按用户先查看 HTML 的选择，尚未公网部署。

## 原型边界

目录选择通过名称和位置演示，不读写真实磁盘，也不扫描已有文件夹。正式客户端将调用系统文件夹选择器。知识库、项目和文档保存在当前浏览器的 `kbase-v3-data` 中；不同知识库的数据相互分开，但不会跨浏览器或设备同步。

编辑支持基础内容块、斜杠菜单、源码转换、自动保存与 Ctrl/Cmd + S。源码转换尚不支持完整 Markdown 保真，不能作为正式编辑器使用。同步、设备、冲突和日志均为演示。原型不会发出同步请求，不保存配对凭据；请勿输入敏感内容。

v1、v2 设计稿在 `design/archive/`；UI 03 不自动迁移旧原型的浏览器草稿。TypeScript 与生产构建已通过，关键流程在 Chromium 中验证。
